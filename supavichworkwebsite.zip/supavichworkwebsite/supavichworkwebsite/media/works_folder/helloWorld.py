print("Hello World")
print("King")